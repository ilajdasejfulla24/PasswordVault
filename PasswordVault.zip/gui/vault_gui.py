import tkinter as tk

def run_app():
    root=tk.Tk()
    root.title('Password Vault')
    tk.Label(root,text='Password Vault Skeleton Project').pack(padx=20,pady=20)
    root.mainloop()
