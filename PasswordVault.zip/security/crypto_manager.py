from cryptography.fernet import Fernet

class CryptoManager:
    def __init__(self,key=None):
        self.key = key or Fernet.generate_key()
        self.fernet = Fernet(self.key)
