import random,string

def generate(length=16):
    chars=string.ascii_letters+string.digits+string.punctuation
    return ''.join(random.choice(chars) for _ in range(length))
