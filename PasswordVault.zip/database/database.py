import sqlite3

class Database:
    def __init__(self, db='vault.db'):
        self.conn = sqlite3.connect(db)
        self.conn.execute('CREATE TABLE IF NOT EXISTS credentials(id INTEGER PRIMARY KEY, site TEXT, username TEXT, password TEXT, notes TEXT)')
        self.conn.commit()
